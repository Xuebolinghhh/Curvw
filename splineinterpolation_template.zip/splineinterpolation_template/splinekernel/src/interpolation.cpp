#include "interpolation.hpp"
#include "basisfunctions.hpp"
#include "linalg.hpp"
#include <string>
#include <cmath>
#include <exception>

namespace cie
{
   namespace splinekernel
   {
	  ControlPointsAndKnotVector interpolateWithBSplineCurve(const ControlPoints2D& interpolationPoints,
		size_t polynomialDegree)
	  {

		// Throw exception if number of x-values is not equal number of y-values
		if (interpolationPoints[0].size() != interpolationPoints[1].size())
		{
			throw std::range_error("number of x-values is not equal number of y-values");

		}
		
			size_t n = interpolationPoints[0].size();
			std::vector<double> tk = centripetalParameterPositions(interpolationPoints);
			std::vector<double> U = knotVectorUsingAveraging(tk, polynomialDegree);
			std::vector<std::vector<double>> matrix(n);

			for (size_t j = 0; j < n; j++)
			{
				matrix[j].resize(n);
				for (size_t i = 0; i < n; i++)
				{
					matrix[j][i] = evaluateBSplineBasis(tk[j], i, polynomialDegree, U);
					 
				}
			}

			linalg::Matrix NMatrix(matrix);

			std::vector<double> Px(linalg::solve(NMatrix, interpolationPoints[0]));
			std::vector<double> Py(linalg::solve(NMatrix, interpolationPoints[1]));
			ControlPoints2D P = { Px,Py };
			return { P, U };
		
	  }

			std::vector<double> centripetalParameterPositions(const ControlPoints2D& interpolationPoints)
			{
				
				size_t n = interpolationPoints[0].size();
				std::vector<double> dk;
				double dsum(0.0);
				
				for (size_t j = 0; j < n - 1; j++)
				{
					double dkx = abs(interpolationPoints[0][j + 1] - interpolationPoints[0][j]);
					double dky = abs(interpolationPoints[1][j + 1] - interpolationPoints[1][j]);
					double d = sqrt(pow(dkx, 2) + pow(dky, 2));
						dsum += sqrt(d);
						dk.push_back(d);
				}

				std::vector<double> tk;
				tk.push_back(0.0);

				for (size_t i = 1; i < n; i++)
				{
					tk.push_back(tk[i - 1] + sqrt(dk[i - 1]) / dsum);
				}
				return  tk ;
				
			}
			



			std::vector<double> knotVectorUsingAveraging(const std::vector<double>& parameterPositions,
				size_t polynomialDegree)
			{
				size_t m, n;
				n = parameterPositions.size();
				m = n + polynomialDegree + 1;
				// Throw exception if polynomial degree is too high for given number of points
				if (polynomialDegree > n-1)
				{
					throw std::range_error("Polynomial degree is too high for given number of points");
				}

				std::vector<double> U(m, 0.0);
			
					for (size_t i = 0; i < polynomialDegree + 1; i++)
					{
						U[i] = 0.0;
					}

					for (size_t j = m - polynomialDegree - 1; j < m; j++)
					{
						U[j] = 1.0;
					}

					for (size_t i = 0; i < n-polynomialDegree-1; i++)
					{
						double t(0.0);
						for (size_t j = 0; j <polynomialDegree; j++)
						{

							t += parameterPositions[j+i+1];
						}
						U[polynomialDegree+i+1] = t / polynomialDegree;
					}

					return U ;		
			}
		
   } // namespace splinekernel
} // namespace cie
